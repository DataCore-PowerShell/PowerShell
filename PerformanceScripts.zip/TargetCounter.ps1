﻿cls
Set-StrictMode -Version latest 
<## Script to capture target perf counters on iSCSI targets
Enter the following data and the file will be outputted as a CSV where indicated##>

# Enter average interval in seconds
$interval = 5
#Enter seconds for capture to run
$time = 120
#Enter SDS to log into
$SDS = "SDS1"
#Enter Output file
$out = "c:\Temp\targetperfdata.csv"
#Enter User Name
$user = 'SSVAdmin'
#Enter Password
$pass = 'SSVPassword'

function writeperf($PerfCtr, $PerfCtr_Lastrun)	{
	$timediff = ($PerfCtr.CollectionTime.Ticks - $PerfCtr_Lastrun.CollectionTime.Ticks) / [Math]::Pow(10,7)
	$MBdiff = $timediff *[Math]::Pow(2,20)
    $TMT = [Math]::Round(($PerfCtr.TargetBytesTransferred - $PerfCtr_Lastrun.TargetBytesTransferred) / $MBdiff,3)
    $RMB = [Math]::Round(($PerfCtr.TargetBytesRead - $PerfCtr_Lastrun.TargetBytesRead)  / $MBdiff,3)
    $WMB = [Math]::Round(($PerfCtr.TargetBytesWritten - $PerfCtr_Lastrun.TargetBytesWritten)  / $MBdiff,3)
    $TIO = [Math]::Round((($PerfCtr.TargetOperations - $PerfCtr_Lastrun.TargetOperations) / $timediff ),3)
    $RIO = [Math]::Round((($PerfCtr.TargetReads - $PerfCtr_Lastrun.TargetReads) / $timediff ),3)
    $WIO = [Math]::Round((($PerfCtr.TargetWrites - $PerfCtr_Lastrun.TargetWrites) / $timediff	 ),3)
	If (($PerfCtr.TargetReads - $PerfCtr_Lastrun.TargetReads) -eq 0)	{ $RLat = 0}
       else {$RLat = [Math]::Round((($PerfCtr.TargetReadTime - $PerfCtr_Lastrun.TargetReadTime) / (($PerfCtr.TargetReads - $PerfCtr_Lastrun.TargetReads) )  ),2)
	}
	if (($PerfCtr.TargetWrites - $PerfCtr_Lastrun.TargetWrites) -eq 0) {$WLat = 0}
       else  {$WLat = [Math]::Round((($PerfCtr.TargetWriteTime - $PerfCtr_Lastrun.TargetWriteTime) / (($PerfCtr.TargetWrites - $PerfCtr_Lastrun.TargetWrites))),2)
	}
	$OIO = $PerfCtr.PendingTargetCommands 
return "$TMT,$RMB,$WMB,$TIO,$RIO,$WIO,$RLat,$WLat,$OIO,"
}

Connect-DcsServer -Connection SSVCON -Server $SDS -UserName $user	-Password $pass
$target = Get-DcsPort   -Type iSCSI 
$lastperf = @{}
$tarray = @()
$now = Get-Date -format s
$header = [string]$now + ","
foreach ($t in $target)	{
	$perf = Get-DcsPerformanceCounter $t.id
	$lastperf.add($t, $perf)
	$tarray += $t
	$ss = Get-DcsServer -Server  $t.HostId
	$dname = $ss.HostName + "/" +  $t.Alias 
	$header = $header + "TMB $dname,RMB $dname,WMB $dname,TIO $dname,RIO $dname,WIO $dname,RLat $dname,WLat$dname,PendTar $dname," 
	
}
sc $out $header
sleep -Seconds $Interval 
$perfhash = @{}
$tm = 0
while ($tm -lt $time)	{
	$now = Get-Date -format s
	$data = [string]$now +","
	foreach ($tar in $tarray)  {
	        $Perf = Get-DcsPerformanceCounter $tar
			$perfhash.add($tar,$Perf)
			$oldperf = $lastperf.get_item($tar) 
			$dret = writeperf $Perf $oldperf
			$data = $data + $dret 
	}
ac $out $data	
$lastperf=$perfhash
$perfhash = @{}
sleep -Seconds $interval
$tm += $interval
}


Disconnect-DcsServer -connection SSVCON
