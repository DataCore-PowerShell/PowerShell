﻿<## Script to capture MB/s, IO/s and latencies for all physical disks in pools.
        Enter the following data and the file will be outputted as a CSV where indicated##>
cls
Set-StrictMode -Version latest 

# Enter average interval in seconds
$interval = 5
#Enter seconds for capture to run
$time = 120
#Enter SDS to log into
$SDS = "SDS1"
#Enter Output file
$out = "c:\Temp\perfdata.csv"
#Enter User Name
$user = 'SSV Admin'
#Enter Password
$pass = 'Password'

function writeperf($PerfCtr, $PerfCtr_Lastrun)	{
	$timediff = ($PerfCtr.CollectionTime.Ticks - $PerfCtr_Lastrun.CollectionTime.Ticks) / [Math]::Pow(10,7)
	$MBdiff = $timediff *[Math]::Pow(2,20)
    $TMT = [Math]::Round(($PerfCtr.TotalBytesTransferred - $PerfCtr_Lastrun.TotalBytesTransferred) / $MBdiff,3)
    $RMB = [Math]::Round(($PerfCtr.TotalBytesRead - $PerfCtr_Lastrun.TotalBytesRead)  / $MBdiff,3)
    $WMB = [Math]::Round(($PerfCtr.TotalBytesWritten - $PerfCtr_Lastrun.TotalBytesWritten)  / $MBdiff,3)
    $TIO = [Math]::Round((($PerfCtr.TotalOperations - $PerfCtr_Lastrun.TotalOperations) / $timediff ),3)
    $RIO = [Math]::Round((($PerfCtr.TotalReads - $PerfCtr_Lastrun.TotalReads) / $timediff ),3)
    $WIO = [Math]::Round((($PerfCtr.TotalWrites - $PerfCtr_Lastrun.TotalWrites) / $timediff	 ),3)
	If (($PerfCtr.TotalReads - $PerfCtr_Lastrun.TotalReads) -eq 0)	{ $RLat = 0}
       else {$RLat = [Math]::Round((($PerfCtr.TotalReadsTime - $PerfCtr_Lastrun.TotalReadsTime) / (($PerfCtr.TotalReads - $PerfCtr_Lastrun.TotalReads) * 10)  ),2)
	}
	if (($PerfCtr.TotalWrites - $PerfCtr_Lastrun.TotalWrites) -eq 0) {$WLat = 0}
       else  {$WLat = [Math]::Round((($PerfCtr.TotalWritesTime - $PerfCtr_Lastrun.TotalWritesTime) / (($PerfCtr.TotalWrites - $PerfCtr_Lastrun.TotalWrites) * 10)),2)
	}
	$OIO = $PerfCtr.TotalPendingCommands 
return "$TMT,$RMB,$WMB,$TIO,$RIO,$WIO,$RLat,$WLat,$OIO,"
}

Connect-DcsServer -Connection CONSSV -Server $SDS -UserName $user	-Password $pass
$pools = Get-DcsPool
$lastperf = @{}
$darray = @()
$now = Get-Date -format s
$header = [string]$now + ","
#Intro Hash
foreach ($p in $pools)	{
	$pdisks = Get-DcsPoolMember -Pool $p.id
	foreach ($pd in $pdisks)  {
		$pdk = Get-DcsPhysicalDisk -Server $p.serverID  -Disk $pd.id
        $Perf = Get-DcsPerformanceCounter $pdk.id
		$lastperf.add($pdk,$Perf)	
		$darray += $pdk
		$ss = Get-DcsServer -Server  $p.ServerID
		$dname = $ss.HostName + "/" +  $p.Alias + "/" + $pd.caption
		$header = $header + "TMB $dname,RMB $dname,WMB $dname,TIO $dname,RIO $dname,WIO $dname,RLat $dname,WLat$dname,OIO $dname," 
	}
}
sc $out $header
sleep -Seconds $Interval 
$perfhash = @{}
$t = 0
while ($t -lt $time)	{
	$now = Get-Date -format s
	$data = [string]$now +","
	foreach ($pd in $darray)  {
			$pdk = Get-DcsPhysicalDisk -Disk $pd.id
	        $Perf = Get-DcsPerformanceCounter $pdk.id
			$perfhash.add($pdk,$Perf)
			$oldperf = $lastperf.get_item($pd) 
			$dret = writeperf $Perf $oldperf
			$data = $data + $dret 
	}
ac $out $data	
$lastperf=$perfhash
$perfhash = @{}
sleep -Seconds $interval
$t += $interval
}

Disconnect-DcsServer -connection CONSSV
