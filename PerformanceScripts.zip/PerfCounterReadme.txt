In this folder are two powershell scripts to capture performance data.  Both scripts are very similar.  

The first script "PoolDiskPerfCounter.txt will capture most of the perf stats for all of the physical disks in pools on both SDSs.  The second script will capture many perf stats for all of the "iSCSI" target channels on both SDSs.

The scripts are pretty bare.  There are a number of variables that have to be set.  All the variables that need modification are at the top of the script.  

The output runs vertically down a csv file.  The first line is a header showing the SDS, the name of the port (or pool/disk) and the type of counter TMB is total MBs, RMB -> Read MBs, WIO -> Write IO etc.  

Once the script is run, use Excel to graph the csv.  

In the "header" capture section of the script you can write a pipe to a where block, such as "| where {$_.alias -match "^iSCSI"}" at line 39 of targetperfcounter.ps1 or "| where {$_.alias -match "^Pool1"} at line 39 of pooldiskperfcounter.ps1 to limit the output to a smaller subset of targets or pools.

These scripts are basic templates for storage admins to capture specific stats.  I will update them as necessary.

